import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { config } from './config.js';

const COOKIE = 'sumi_token';
const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

const cookieOptions = {
  httpOnly: true,
  sameSite: 'lax',
  secure: config.cookieSecure,
  path: '/',
};

// Hash first so both values have equal length, then compare in constant time.
const digest = (value) => crypto.createHash('sha256').update(String(value)).digest();
const same = (a, b) => crypto.timingSafeEqual(digest(a), digest(b));

export function checkCredentials(username, password) {
  const userOk = same(username, config.adminUsername);
  const passOk = same(password, config.adminPassword);
  return userOk && passOk;
}

export function startSession(res) {
  const token = jwt.sign({ sub: config.adminUsername }, config.jwtSecret, { expiresIn: '7d' });
  res.cookie(COOKIE, token, { ...cookieOptions, maxAge: WEEK_MS });
}

export function endSession(res) {
  res.clearCookie(COOKIE, cookieOptions);
}

export function readSession(req) {
  const token = req.cookies?.[COOKIE];
  if (!token) return null;
  try {
    return jwt.verify(token, config.jwtSecret);
  } catch {
    return null;
  }
}

export function requireAdmin(req, res, next) {
  const session = readSession(req);
  if (!session) return res.status(401).json({ error: 'Please log in to continue.' });
  req.admin = session;
  next();
}

export const currentUser = () => ({ username: config.adminUsername, name: config.adminName });
