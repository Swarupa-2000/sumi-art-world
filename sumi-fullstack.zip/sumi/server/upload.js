import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import multer from 'multer';
import { config } from './config.js';
import { HttpError } from './errors.js';
import { isImageInUse, isSeedImage } from './store.js';

const EXTENSIONS = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' };

export const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, config.uploadsDir),
    filename: (req, file, cb) => cb(null, crypto.randomUUID() + EXTENSIONS[file.mimetype]),
  }),
  limits: { fileSize: config.maxUploadBytes, files: 1 },
  fileFilter: (req, file, cb) =>
    EXTENSIONS[file.mimetype] ? cb(null, true) : cb(new HttpError(400, 'The image must be a JPG, PNG or WebP file.')),
});

// The browser-supplied MIME type can be faked, so also check the file's first bytes.
export async function assertRealImage(file) {
  const handle = await fs.open(file.path, 'r');
  const head = Buffer.alloc(12);
  try {
    await handle.read(head, 0, 12, 0);
  } finally {
    await handle.close();
  }
  const isJpeg = head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff;
  const isPng = head.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  const isWebp = head.subarray(0, 4).toString() === 'RIFF' && head.subarray(8, 12).toString() === 'WEBP';
  if (!(isJpeg || isPng || isWebp)) throw new HttpError(400, 'That file is not a valid JPG, PNG or WebP image.');
}

export const removeUploadedFile = (file) => fs.rm(file.path, { force: true });

// Delete an image from disk once no artwork uses it any more (sample images are kept).
export async function discardImage(imageUrl) {
  if (!imageUrl || isImageInUse(imageUrl) || isSeedImage(imageUrl)) return;
  await fs.rm(path.join(config.uploadsDir, path.basename(imageUrl)), { force: true });
}
