import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { checkCredentials, currentUser, endSession, readSession, startSession } from '../auth.js';

const router = Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again in a few minutes.' },
});

router.post('/login', loginLimiter, (req, res) => {
  const { username, password } = req.body ?? {};
  if (typeof username !== 'string' || typeof password !== 'string' || !checkCredentials(username, password)) {
    return res.status(401).json({ error: 'Wrong username or password.' });
  }
  startSession(res);
  res.json({ user: currentUser() });
});

router.post('/logout', (req, res) => {
  endSession(res);
  res.status(204).end();
});

router.get('/me', (req, res) => {
  if (!readSession(req)) return res.status(401).json({ error: 'Not logged in.' });
  res.json({ user: currentUser() });
});

export default router;
