import { Router } from 'express';
import { requireAdmin } from '../auth.js';
import { asyncHandler, HttpError } from '../errors.js';
import { createArtwork, deleteArtwork, getArtwork, listArtworks, updateArtwork } from '../store.js';
import { assertRealImage, discardImage, removeUploadedFile, upload } from '../upload.js';

const router = Router();

function parseId(raw) {
  const id = Number(raw);
  if (!Number.isInteger(id) || id < 1) throw new HttpError(404, 'Drawing not found.');
  return id;
}

// Validates the text fields. With `partial`, only the fields that were sent are checked.
function parseFields(body = {}, { partial }) {
  const out = {};
  if (!partial || body.title !== undefined) {
    const title = String(body.title ?? '').trim();
    if (!title || title.length > 120) throw new HttpError(400, 'Title is required (up to 120 characters).');
    out.title = title;
  }
  if (!partial || body.description !== undefined) {
    const description = String(body.description ?? '').trim();
    if (description.length > 2000) throw new HttpError(400, 'Description is too long (up to 2000 characters).');
    out.description = description;
  }
  if (!partial || body.price !== undefined) {
    const price = Number(body.price);
    if (!Number.isInteger(price) || price < 1 || price > 10_000_000) {
      throw new HttpError(400, 'Price must be a whole number of rupees, 1 or more.');
    }
    out.price = price;
  }
  if (partial && body.status !== undefined) {
    if (!['available', 'sold'].includes(body.status)) throw new HttpError(400, 'Status must be "available" or "sold".');
    out.status = body.status;
  }
  return out;
}

// Public: the gallery and the admin panel both read this.
router.get('/', (req, res) => res.json(listArtworks()));

router.post(
  '/',
  requireAdmin, // check login before accepting any upload
  upload.single('image'),
  asyncHandler(async (req, res) => {
    try {
      if (!req.file) throw new HttpError(400, 'Choose an image of your drawing.');
      await assertRealImage(req.file);
      const fields = parseFields(req.body, { partial: false });
      const artwork = await createArtwork({ ...fields, image: `/uploads/${req.file.filename}` });
      res.status(201).json(artwork);
    } catch (err) {
      if (req.file) await removeUploadedFile(req.file);
      throw err;
    }
  })
);

router.patch(
  '/:id',
  requireAdmin,
  upload.single('image'), // accepts multipart (with an image) or plain JSON
  asyncHandler(async (req, res) => {
    try {
      const artwork = getArtwork(parseId(req.params.id));
      if (!artwork) throw new HttpError(404, 'Drawing not found.');
      const patch = parseFields(req.body, { partial: true });
      if (req.file) {
        await assertRealImage(req.file);
        patch.image = `/uploads/${req.file.filename}`;
      }
      const oldImage = artwork.image;
      const updated = await updateArtwork(artwork.id, patch);
      if (patch.image) await discardImage(oldImage);
      res.json(updated);
    } catch (err) {
      if (req.file) await removeUploadedFile(req.file);
      throw err;
    }
  })
);

router.delete(
  '/:id',
  requireAdmin,
  asyncHandler(async (req, res) => {
    const artwork = getArtwork(parseId(req.params.id));
    if (!artwork) throw new HttpError(404, 'Drawing not found.');
    await deleteArtwork(artwork.id);
    await discardImage(artwork.image);
    res.status(204).end();
  })
);

export default router;
