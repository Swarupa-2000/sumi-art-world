import fs from 'node:fs';
import cookieParser from 'cookie-parser';
import express from 'express';
import helmet from 'helmet';
import multer from 'multer';
import { config } from './config.js';
import { HttpError } from './errors.js';
import authRoutes from './routes/auth.js';
import artworkRoutes from './routes/artworks.js';
import { initStore } from './store.js';

await initStore();

const app = express();
app.disable('x-powered-by');
if (config.trustProxy) app.set('trust proxy', config.trustProxy);

app.use(helmet({ contentSecurityPolicy: { useDefaults: true, directives: { 'upgrade-insecure-requests': null } } }));
app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());

app.use('/api/auth', authRoutes);
app.use('/api/artworks', artworkRoutes);
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

// Uploaded images (file names are random, so they can be cached for a long time).
app.use('/uploads', express.static(config.uploadsDir, { maxAge: '30d', immutable: true, fallthrough: false }));

// After `npm run build`, this same server also serves the website (/) and the admin panel (/admin/).
if (fs.existsSync(config.distDir)) app.use(express.static(config.distDir));

app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err instanceof multer.MulterError) {
    const tooBig = err.code === 'LIMIT_FILE_SIZE';
    return res.status(tooBig ? 413 : 400).json({ error: tooBig ? 'That image is too large (8 MB maximum).' : 'Upload failed.' });
  }
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON.' });
  if (err.status === 404) return res.status(404).json({ error: 'Not found.' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

app.listen(config.port, () => {
  console.log(`Sumi server running:  http://localhost:${config.port}`);
  console.log(`  Admin panel:        http://localhost:${config.port}/admin/  (after "npm run build")`);
});
