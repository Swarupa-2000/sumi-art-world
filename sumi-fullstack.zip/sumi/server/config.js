import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const isProd = process.env.NODE_ENV === 'production';

// In production, secrets must come from the environment.
// In development we fall back to insecure defaults (and say so) so `npm run dev` just works.
function setting(name, devDefault) {
  const value = process.env[name];
  if (value) return value;
  if (isProd) {
    console.error(`Missing required environment variable ${name}. See .env.example.`);
    process.exit(1);
  }
  console.warn(`[config] ${name} is not set, using an insecure development default.`);
  return devDefault;
}

const storageDir = process.env.STORAGE_DIR
  ? path.resolve(process.env.STORAGE_DIR)
  : path.join(here, 'storage');

export const config = {
  isProd,
  port: Number(process.env.PORT) || 4000,
  adminUsername: setting('ADMIN_USERNAME', 'admin'),
  adminPassword: setting('ADMIN_PASSWORD', 'admin123'),
  adminName: process.env.ADMIN_NAME || 'Sumi',
  jwtSecret: setting('JWT_SECRET', 'dev-only-secret-change-me'),
  cookieSecure: process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === 'true' : isProd,
  trustProxy: process.env.TRUST_PROXY ? Number(process.env.TRUST_PROXY) : 0,
  storageDir,
  uploadsDir: path.join(storageDir, 'uploads'),
  dbFile: path.join(storageDir, 'db.json'),
  seedDir: path.join(here, 'seed'),
  distDir: path.join(here, '..', 'dist'),
  maxUploadBytes: 8 * 1024 * 1024,
};
