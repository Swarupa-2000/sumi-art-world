import fs from 'node:fs/promises';
import path from 'node:path';
import { config } from './config.js';

// A small JSON-file database. It is plenty for one artist's gallery.
// Everything lives in memory; every change is written to disk atomically.
let db = { nextId: 1, artworks: [] };
let writeChain = Promise.resolve();

const SEED_IMAGE = 'seed-watercolor.svg';
const seedArtworks = [
  { title: 'Mountain Lake Landscape', price: 4500, status: 'available', createdAt: '2026-10-03T12:00:00.000Z', description: 'Watercolor landscape of mountains, trees, a lake and open countryside.' },
  { title: 'Trees by the Lake', price: 3200, status: 'available', createdAt: '2026-10-02T12:00:00.000Z', description: 'Colorful watercolor study featuring tall trees, water and distant hills.' },
  { title: 'Blue Mountain View', price: 2800, status: 'available', createdAt: '2026-09-30T12:00:00.000Z', description: 'Watercolor landscape with layered blue mountains and a bright sky.' },
  { title: 'Countryside Watercolor', price: 5200, status: 'available', createdAt: '2026-09-28T12:00:00.000Z', description: 'Hand-painted watercolor scene with fields, trees and a peaceful lakeside.' },
  { title: 'Summer Landscape', price: 3500, status: 'sold', createdAt: '2026-09-20T12:00:00.000Z', description: 'Vibrant watercolor landscape with warm earth tones and green fields.' },
  { title: 'Peaceful Lakeside', price: 3000, status: 'available', createdAt: '2026-09-18T12:00:00.000Z', description: 'A scenic watercolor painting of a quiet lake, trees and mountains.' },
];

function persist() {
  const write = async () => {
    const tmp = `${config.dbFile}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(db, null, 2));
    await fs.rename(tmp, config.dbFile);
  };
  const run = writeChain.then(write);
  writeChain = run.catch(() => {}); // a failed write must not block later ones
  return run;
}

export async function initStore() {
  await fs.mkdir(config.uploadsDir, { recursive: true });
  try {
    db = JSON.parse(await fs.readFile(config.dbFile, 'utf8'));
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    // First run: create the sample gallery.
    await fs.copyFile(path.join(config.seedDir, 'watercolor.svg'), path.join(config.uploadsDir, SEED_IMAGE));
    db = {
      nextId: seedArtworks.length + 1,
      artworks: seedArtworks.map((a, i) => ({ id: i + 1, ...a, image: `/uploads/${SEED_IMAGE}` })),
    };
    await persist();
    console.log('[store] Created sample gallery with', seedArtworks.length, 'artworks.');
  }
}

export const listArtworks = () =>
  [...db.artworks].sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id - a.id);

export const getArtwork = (id) => db.artworks.find((a) => a.id === id) ?? null;

export async function createArtwork(fields) {
  const artwork = { id: db.nextId++, ...fields, status: 'available', createdAt: new Date().toISOString() };
  db.artworks.push(artwork);
  await persist();
  return artwork;
}

export async function updateArtwork(id, patch) {
  const artwork = getArtwork(id);
  Object.assign(artwork, patch);
  await persist();
  return artwork;
}

export async function deleteArtwork(id) {
  db.artworks = db.artworks.filter((a) => a.id !== id);
  await persist();
}

export const isImageInUse = (image) => db.artworks.some((a) => a.image === image);
export const isSeedImage = (image) => path.basename(image) === SEED_IMAGE;
