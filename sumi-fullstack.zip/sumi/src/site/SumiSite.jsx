import { useEffect, useRef, useState } from 'react';
import './SumiSite.css';
import { api } from '../shared/api';

const money = (n) => '₹' + n.toLocaleString('en-IN');

const FILTERS = [
  { key: 'all', label: 'All Works' },
  { key: 'available', label: 'Available' },
  { key: 'sold', label: 'Sold' },
];

function ArtCard({ art, onOpen }) {
  return (
    <article
      className="card"
      tabIndex={0}
      onClick={() => onOpen(art)}
      onKeyDown={(e) => e.key === 'Enter' && onOpen(art)}
    >
      <div className="artbox">
        <img src={art.image} alt={art.title} />
        <span className={`badge ${art.status}`}>{art.status}</span>
      </div>
      <div className="card-body">
        <h3>{art.title}</h3>
        <div className="artist">Original watercolor · Sumi</div>
        <div className="card-foot">
          <span className="price">{money(art.price)}</span>
          <span className="view">View details →</span>
        </div>
      </div>
    </article>
  );
}

function ArtModal({ art, onClose, onContact }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="modal open" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-card">
        <div className="modal-img">
          <img src={art.image} alt={art.title} />
        </div>
        <div className="modal-copy">
          <button className="close" onClick={onClose} aria-label="Close">×</button>
          <div className="eyebrow">Original Artwork · Sumi</div>
          <h2>{art.title}</h2>
          <div
            className={`badge ${art.status}`}
            style={{ position: 'static', display: 'inline-block', margin: '0 0 10px' }}
          >
            {art.status}
          </div>
          <p>{art.description}</p>
          <div className="price" style={{ margin: '20px 0' }}>{money(art.price)}</div>
          <button className="btn" onClick={onContact}>Ask About This Artwork</button>
        </div>
      </div>
    </div>
  );
}

export default function SumiSite() {
  const [artworks, setArtworks] = useState([]);
  const [loadState, setLoadState] = useState('loading'); // loading | ready | error
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [toast, setToast] = useState(false);
  const searchRef = useRef(null);
  const toastTimer = useRef(null);

  useEffect(() => () => clearTimeout(toastTimer.current), []);

  useEffect(() => {
    let cancelled = false;
    api
      .listArtworks()
      .then((list) => {
        if (cancelled) return;
        setArtworks(list);
        setLoadState('ready');
      })
      .catch(() => !cancelled && setLoadState('error'));
    return () => {
      cancelled = true;
    };
  }, []);

  const contactArtist = () => {
    setToast(true);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(false), 2800);
  };

  const heroImage = (artworks.find((a) => a.status === 'available') ?? artworks[0])?.image;

  const items = artworks.filter(
    (a) =>
      (filter === 'all' || a.status === filter) &&
      a.title.toLowerCase().includes(search.toLowerCase())
  );

  const closeMenu = () => setMenuOpen(false);

  return (
    <>
      <div className="top">Original Watercolor Art · One Artist · Sumi</div>

      <header>
        <div className="container nav">
          <a className="logo" href="#home">
            <span className="logo-mark">S</span>
            <span>
              <strong>Sumi</strong>
              <small>Watercolor Gallery</small>
            </span>
          </a>
          <nav className={`links${menuOpen ? ' open' : ''}`}>
            <a className="active" href="#home" onClick={closeMenu}>Home</a>
            <a href="#collection" onClick={closeMenu}>Collection</a>
            <a href="#about" onClick={closeMenu}>About Sumi</a>
            <a href="#contact" onClick={closeMenu}>Contact</a>
          </nav>
          <div className="nav-actions">
            <button className="icon mobile" onClick={() => setMenuOpen((o) => !o)} aria-label="Menu">☰</button>
            <button className="icon" onClick={() => searchRef.current?.focus()} aria-label="Search">⌕</button>
          </div>
        </div>
      </header>

      <main id="home">
        <div className="container">
          <section className="hero">
            <div className="hero-copy">
              <span className="kicker">Original Works · Sumi</span>
              <h1>Painted with <em>light</em> &amp; feeling.</h1>
              <p>
                Welcome to Sumi's private watercolor gallery — a quiet collection of landscapes,
                lakes, trees and peaceful moments captured by hand.
              </p>
              <div style={{ display: 'flex', gap: 9, flexWrap: 'wrap' }}>
                <a className="btn" href="#collection">Explore Collection</a>
                <a className="btn light" href="#about">Meet Sumi</a>
              </div>
            </div>
            <div className="hero-art">
              {heroImage && (
                <div className="hero-frame">
                  <img src={heroImage} alt="Featured watercolor" />
                </div>
              )}
            </div>
          </section>

          <section className="section" id="collection">
            <div className="section-head">
              <div>
                <div className="eyebrow">The Collection</div>
                <h2>Recent watercolor works</h2>
              </div>
              <p>Each work is presented as part of Sumi's single-artist collection.</p>
            </div>

            <div className="filters">
              {FILTERS.map((f) => (
                <button
                  key={f.key}
                  className={`filter${filter === f.key ? ' active' : ''}`}
                  onClick={() => setFilter(f.key)}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <input
              ref={searchRef}
              id="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search artwork..."
              aria-label="Search artwork"
              style={{ marginBottom: 20, maxWidth: 420, padding: '12px 15px', border: '1px solid var(--line)', borderRadius: 9, background: '#fff' }}
            />

            <div className="grid">
              {loadState === 'ready' && items.map((a) => <ArtCard key={a.id} art={a} onOpen={setSelected} />)}
              {loadState !== 'ready' || items.length === 0 ? (
                <div style={{ gridColumn: '1/-1', padding: 50, textAlign: 'center', color: 'var(--muted)' }}>
                  {loadState === 'loading' && 'Loading the collection…'}
                  {loadState === 'error' && 'The collection could not be loaded. Please refresh the page.'}
                  {loadState === 'ready' && (artworks.length ? 'No artwork found.' : 'New works are coming soon.')}
                </div>
              ) : null}
            </div>
          </section>

          <section className="section" id="about">
            <div className="about">
              <div className="about-card">
                <div className="eyebrow" style={{ color: 'var(--gold2)' }}>The Artist</div>
                <h2>Sumi</h2>
                <p>
                  A single artist, a personal collection, and a love for watercolor landscapes that
                  turn ordinary places into quiet memories.
                </p>
              </div>
              <div className="about-info">
                <h3>A softer way to see the world.</h3>
                <p>
                  Sumi's work focuses on natural light, open landscapes and the small details that
                  make a place feel peaceful. The collection is intentionally intimate: every
                  artwork belongs to Sumi.
                </p>
                <div className="quote">“A painting should leave a little silence behind.”</div>
              </div>
            </div>
          </section>

          <section className="contact" id="contact">
            <div>
              <h2>Interested in a painting?</h2>
              <p>Ask about availability, pricing or a particular artwork.</p>
            </div>
            <button className="btn" onClick={contactArtist}>Contact Sumi</button>
          </section>
        </div>
      </main>

      <footer>
        <div className="container footer">
          <div>
            <strong>Sumi</strong>
            <small>Watercolor Gallery · Original Works</small>
          </div>
          <div>© 2026 Sumi · All artwork reserved</div>
        </div>
      </footer>

      {selected && (
        <ArtModal art={selected} onClose={() => setSelected(null)} onContact={contactArtist} />
      )}

      <div className="toast" style={{ display: toast ? 'block' : 'none' }}>
        Thank you — please contact Sumi about this artwork.
      </div>
    </>
  );
}
