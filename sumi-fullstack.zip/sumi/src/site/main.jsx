import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import SumiSite from './SumiSite';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <SumiSite />
  </StrictMode>
);
