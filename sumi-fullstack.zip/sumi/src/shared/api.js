// One small client for the Node backend. Used by both the gallery and the admin panel.
async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(path, { credentials: 'same-origin', ...options });
  } catch {
    throw new Error('Cannot reach the server. Is it running?');
  }
  if (res.status === 204) return null;
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON response */
  }
  if (!res.ok) {
    const err = new Error(data?.error || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

const json = (method, body) => ({
  method,
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body),
});

export const api = {
  listArtworks: () => request('/api/artworks'),

  me: () => request('/api/auth/me'),
  login: (username, password) => request('/api/auth/login', json('POST', { username, password })),
  logout: () => request('/api/auth/logout', { method: 'POST' }),

  // `form` is a FormData with title, description, price and (optionally) image.
  createArtwork: (form) => request('/api/artworks', { method: 'POST', body: form }),
  updateArtwork: (id, form) => request(`/api/artworks/${id}`, { method: 'PATCH', body: form }),
  setStatus: (id, status) => request(`/api/artworks/${id}`, json('PATCH', { status })),
  deleteArtwork: (id) => request(`/api/artworks/${id}`, { method: 'DELETE' }),
};

export const formatDate = (iso) =>
  new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
