import { useEffect, useState } from 'react';
import './SumiAdmin.css';
import { api, formatDate } from '../shared/api';

/* ---------- helpers ---------- */

const inr = (n) => '₹' + n.toLocaleString('en-IN');

const ICONS = {
  search: <><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></>,
  dash: <><rect width="7" height="9" x="3" y="3" rx="1" /><rect width="7" height="5" x="14" y="3" rx="1" /><rect width="7" height="9" x="14" y="12" rx="1" /><rect width="7" height="5" x="3" y="16" rx="1" /></>,
  images: <><rect width="18" height="18" x="3" y="3" rx="2" /><circle cx="9" cy="9" r="2" /><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" /></>,
  plus: <><circle cx="12" cy="12" r="10" /><path d="M8 12h8M12 8v8" /></>,
  globe: <><circle cx="12" cy="12" r="10" /><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20M2 12h20" /></>,
  out: <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" />,
  check: <><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></>,
  tag: <><path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z" /><circle cx="7.5" cy="7.5" r=".5" fill="currentColor" /></>,
  rupee: <path d="M6 3h12M6 8h12M6 13l8.5 8M6 13h3M9 13c6.667 0 6.667-10 0-10" />,
  img: <><rect width="18" height="18" x="3" y="3" rx="2" /><circle cx="9" cy="9" r="2" /><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" /></>,
  pal: <><circle cx="13.5" cy="6.5" r=".5" /><circle cx="17.5" cy="10.5" r=".5" /><circle cx="8.5" cy="7.5" r=".5" /><circle cx="6.5" cy="12.5" r=".5" /><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z" /></>,
};

function Icon({ name, size = 18 }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {ICONS[name]}
    </svg>
  );
}

const TITLES = { dash: 'Dashboard', list: 'Drawings', new: 'Add a drawing', edit: 'Edit drawing' };
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;

/* ---------- small components ---------- */

function Pill({ status }) {
  const sold = status === 'sold';
  return <span className={`pill ${sold ? 'bad' : 'ok'}`}>{sold ? 'Sold' : 'Available'}</span>;
}

function Sidebar({ view, open, onNavigate, onLogout }) {
  const go = (v) => (e) => {
    e.preventDefault();
    onNavigate(v);
  };
  const Item = ({ v, icon, label }) => (
    <a href="#" className={(view === 'edit' ? 'list' : view) === v ? 'active' : ''} onClick={go(v)}>
      <Icon name={icon} />
      {label}
    </a>
  );

  return (
    <aside className={`side dark${open ? ' open' : ''}`}>
      <a href="#" className="brand" onClick={go('dash')}>
        <span className="logo"><Icon name="pal" size={20} /></span>
        <span>Sumi<small>Admin panel</small></span>
      </a>
      <div>
        <p className="nav-label">Manage</p>
        <nav className="nav">
          <Item v="dash" icon="dash" label="Dashboard" />
          <Item v="list" icon="images" label="Drawings" />
          <Item v="new" icon="plus" label="Add a drawing" />
        </nav>
      </div>
      <div className="side-foot">
        <nav className="nav">
          <a href="/">
            <Icon name="globe" />View website
          </a>
          <button type="button" onClick={onLogout}>
            <Icon name="out" />Log out
          </button>
        </nav>
      </div>
    </aside>
  );
}

function DrawingRow({ drawing, onToggle, onEdit, onDelete }) {
  const showActions = Boolean(onToggle);
  const sold = drawing.status === 'sold';
  return (
    <tr>
      <td>
        <div className="cell">
          <img src={drawing.image} alt="" />
          <div>
            <b>{drawing.title}</b>
            <span>ID #{drawing.id}</span>
          </div>
        </div>
      </td>
      <td><span className="price">{inr(drawing.price)}</span></td>
      <td><Pill status={drawing.status} /></td>
      <td>{formatDate(drawing.createdAt)}</td>
      {showActions && (
        <td>
          <div className="acts">
            <button className="btn ghost sm" type="button" onClick={() => onToggle(drawing.id)}>
              {sold ? 'Mark available' : 'Mark as sold'}
            </button>
            {!sold && (
              <>
                <button className="btn ghost sm" type="button" onClick={() => onEdit(drawing)}>Edit</button>
                <button className="btn danger sm" type="button" onClick={() => onDelete(drawing.id)}>
                  Delete
                </button>
              </>
            )}
          </div>
        </td>
      )}
    </tr>
  );
}

/* ---------- pages ---------- */

function Dashboard({ user, drawings, onNavigate }) {
  const sold = drawings.filter((d) => d.status === 'sold');
  const earned = sold.reduce((sum, d) => sum + d.price, 0);

  const stats = [
    { icon: 'images', tone: '', label: 'Total drawings', value: drawings.length },
    { icon: 'check', tone: 'ok', label: 'Available', value: drawings.length - sold.length },
    { icon: 'tag', tone: 'bad', label: 'Sold', value: sold.length },
    { icon: 'rupee', tone: 'amber', label: 'Total earned', value: inr(earned) },
  ];

  return (
    <>
      <div className="page-head">
        <div>
          <h2>Hello, {user.name}</h2>
          <p className="note">Here’s how your drawings are doing.</p>
        </div>
        <a className="btn" href="#" onClick={(e) => { e.preventDefault(); onNavigate('new'); }}>
          <Icon name="plus" size={16} />Add a drawing
        </a>
      </div>

      <div className="stats">
        {stats.map((s) => (
          <div className="stat" key={s.label}>
            <span className={`ic ${s.tone}`}><Icon name={s.icon} size={22} /></span>
            <div>
              <p>{s.label}</p>
              <h3>{s.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="sec-head">
        <h2>Recent drawings</h2>
        <a href="#" className="more" onClick={(e) => { e.preventDefault(); onNavigate('list'); }}>
          View all
        </a>
      </div>

      <div className="tcard">
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Drawing</th><th>Price</th><th>Status</th><th>Added</th></tr>
            </thead>
            <tbody>
              {drawings.slice(0, 5).map((d) => (
                <DrawingRow key={d.id} drawing={d} />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

function DrawingList({ drawings, onNavigate, onToggle, onEdit, onDelete }) {
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const visible = drawings.filter(
    (d) =>
      (statusFilter === 'all' || d.status === statusFilter) &&
      d.title.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <>
      <div className="page-head">
        <div>
          <h2>Drawings</h2>
          <p className="note">{drawings.length} total · Mark as sold after a phone order.</p>
        </div>
        <a className="btn" href="#" onClick={(e) => { e.preventDefault(); onNavigate('new'); }}>
          <Icon name="plus" size={16} />Add a drawing
        </a>
      </div>

      <div className="tcard">
        <div className="toolbar">
          <div className="search">
            <Icon name="search" />
            <input
              placeholder="Search by title"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search drawings"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            aria-label="Filter by status"
          >
            <option value="all">All status</option>
            <option value="available">Available</option>
            <option value="sold">Sold</option>
          </select>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Drawing</th><th>Price</th><th>Status</th><th>Added</th><th></th></tr>
            </thead>
            <tbody>
              {visible.map((d) => (
                <DrawingRow key={d.id} drawing={d} onToggle={onToggle} onEdit={onEdit} onDelete={onDelete} />
              ))}
            </tbody>
          </table>
          {visible.length === 0 && <p className="empty">No drawings match your filters.</p>}
        </div>
      </div>
    </>
  );
}

function DrawingForm({ initial, onNavigate, onSave }) {
  const editing = Boolean(initial);
  const [title, setTitle] = useState(initial?.title ?? '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [price, setPrice] = useState(initial ? String(initial.price) : '');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(initial?.image ?? '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const handleFile = (e) => {
    const picked = e.target.files[0];
    if (!picked) return;
    if (picked.size > MAX_IMAGE_BYTES) {
      setError('That image is larger than 8 MB. Please choose a smaller one.');
      e.target.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setFile(picked);
      setPreview(reader.result);
      setError('');
    };
    reader.readAsDataURL(picked);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!preview) {
      setError('Choose an image of your drawing');
      return;
    }
    const form = new FormData();
    form.append('title', title);
    form.append('description', description);
    form.append('price', price);
    if (file) form.append('image', file);

    setSaving(true);
    setError('');
    try {
      await onSave(form);
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="page-head">
        <div>
          <h2>{editing ? 'Edit drawing' : 'Add a drawing'}</h2>
          <p className="note">
            {editing ? 'Changes appear on your website right after you save.' : 'It appears on your website right after you save.'}
          </p>
        </div>
      </div>

      <div className="formgrid">
        <div className="drop">
          {preview ? (
            <img src={preview} alt="Preview" />
          ) : (
            <div>
              <Icon name="img" size={32} />
              <p>Click to upload a photo or scan</p>
              <p className="note small">JPG, PNG or WebP, up to 8 MB</p>
            </div>
          )}
          <input type="file" accept="image/jpeg,image/png,image/webp" aria-label="Drawing image" onChange={handleFile} />
        </div>

        <div className="panel stack">
          <div className="field">
            <label htmlFor="t">Title</label>
            <input id="t" required maxLength={120} value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="d">Description</label>
            <textarea
              id="d"
              rows={5}
              maxLength={2000}
              placeholder="Medium, size, year, anything a buyer should know"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="p">Price in ₹</label>
            <input id="p" type="number" min="1" step="1" required value={price} onChange={(e) => setPrice(e.target.value)} />
          </div>
          <p className="error">{error}</p>
          <div style={{ display: 'flex', gap: '.7rem' }}>
            <button className="btn" disabled={saving}>
              {saving ? 'Saving…' : editing ? 'Save changes' : 'Publish drawing'}
            </button>
            <a className="btn ghost" href="#" onClick={(e) => { e.preventDefault(); onNavigate('list'); }}>
              Cancel
            </a>
          </div>
        </div>
      </div>
    </form>
  );
}

function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const { user } = await api.login(username, password);
      onLogin(user);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };

  const brand = (
    <span className="brand">
      <span className="logo"><Icon name="pal" size={20} /></span>
      <span>Sumi<small>Admin panel</small></span>
    </span>
  );

  return (
    <div className="auth">
      <div className="auth-art">
        {brand}
        <div>
          <h2>Your gallery, in your hands.</h2>
          <ul>
            <li>Add a new drawing in a minute</li>
            <li>Mark a piece as sold after a phone order</li>
            <li>See what you have earned so far</li>
          </ul>
        </div>
        <span />
      </div>
      <div className="auth-form-wrap">
        <form className="auth-form" onSubmit={handleSubmit}>
          {brand}
          <h1>Log in</h1>
          <p className="note">Sign in to manage your drawings.</p>
          <div className="field">
            <label htmlFor="u">Username</label>
            <input id="u" autoComplete="username" required value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="pw">Password</label>
            <input id="pw" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <p className="error">{error}</p>
          <button className="btn block" disabled={busy}>{busy ? 'Logging in…' : 'Log in'}</button>
          <p className="foot-note"><a href="/">Back to website</a></p>
        </form>
      </div>
    </div>
  );
}

/* ---------- app ---------- */

function Panel({ user, onLogout, onSessionExpired }) {
  const [view, setView] = useState('dash');
  const [drawings, setDrawings] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [editing, setEditing] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState('');

  // Runs an API call; if the login has expired, go back to the login screen.
  const run = async (fn) => {
    try {
      setNotice('');
      return await fn();
    } catch (err) {
      if (err.status === 401) onSessionExpired();
      else setNotice(err.message);
      throw err;
    }
  };

  useEffect(() => {
    run(() => api.listArtworks())
      .then((list) => {
        setDrawings(list);
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const navigate = (v) => {
    setView(v);
    setEditing(null);
    setNotice('');
    setMenuOpen(false);
  };

  const toggleSold = (id) => {
    const current = drawings.find((d) => d.id === id);
    const next = current.status === 'sold' ? 'available' : 'sold';
    run(() => api.setStatus(id, next))
      .then((updated) => setDrawings((list) => list.map((d) => (d.id === id ? updated : d))))
      .catch(() => {});
  };

  const remove = (id) => {
    const target = drawings.find((d) => d.id === id);
    if (!window.confirm(`Delete “${target.title}”? This cannot be undone.`)) return;
    run(() => api.deleteArtwork(id))
      .then(() => setDrawings((list) => list.filter((d) => d.id !== id)))
      .catch(() => {});
  };

  const startEdit = (drawing) => {
    setEditing(drawing);
    setView('edit');
    setNotice('');
  };

  const add = async (form) => {
    const created = await run(() => api.createArtwork(form));
    setDrawings((list) => [created, ...list]);
    navigate('list');
  };

  const saveEdit = async (form) => {
    const updated = await run(() => api.updateArtwork(editing.id, form));
    setDrawings((list) => list.map((d) => (d.id === updated.id ? updated : d)));
    navigate('list');
  };

  return (
    <div className="shell">
      {menuOpen && <div className="scrim" onClick={() => setMenuOpen(false)} />}
      <Sidebar view={view} open={menuOpen} onNavigate={navigate} onLogout={onLogout} />

      <div className="col">
        <header className="bar">
          <button className="iconbtn" aria-label="Open menu" onClick={() => setMenuOpen(true)}>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <h1>{TITLES[view]}</h1>
          <span className="grow" />
          <div className="me">
            <span className="hide-sm">{user.name}</span>
            <span className="avatar">{user.name.charAt(0).toUpperCase()}</span>
          </div>
        </header>

        <main className="content">
          {notice && <p className="error" role="alert" style={{ marginBottom: '1rem' }}>{notice}</p>}
          {!loaded ? (
            <p className="note">Loading your drawings…</p>
          ) : (
            <>
              {view === 'dash' && <Dashboard user={user} drawings={drawings} onNavigate={navigate} />}
              {view === 'list' && (
                <DrawingList drawings={drawings} onNavigate={navigate} onToggle={toggleSold} onEdit={startEdit} onDelete={remove} />
              )}
              {view === 'new' && <DrawingForm onNavigate={navigate} onSave={add} />}
              {view === 'edit' && editing && <DrawingForm key={editing.id} initial={editing} onNavigate={navigate} onSave={saveEdit} />}
            </>
          )}
        </main>
      </div>
    </div>
  );
}

export default function SumiAdmin() {
  const [user, setUser] = useState(undefined); // undefined = checking, null = logged out

  useEffect(() => {
    api
      .me()
      .then(({ user }) => setUser(user))
      .catch(() => setUser(null));
  }, []);

  const logout = async () => {
    try {
      await api.logout();
    } finally {
      setUser(null);
    }
  };

  if (user === undefined) return null;
  if (user === null) return <Login onLogin={setUser} />;
  return <Panel user={user} onLogout={logout} onSessionExpired={() => setUser(null)} />;
}
