import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import SumiAdmin from './SumiAdmin';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <SumiAdmin />
  </StrictMode>
);
