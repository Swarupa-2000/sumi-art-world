# Sumi — Gallery + Admin Panel (React + Node.js)

| URL        | What it is                                     |
|------------|------------------------------------------------|
| `/`        | Customer gallery                               |
| `/admin/`  | Admin panel (needs login)                      |
| `/api/...` | Node.js (Express) backend, shared by both      |

The admin panel adds, edits, sells and deletes drawings. The gallery shows the same drawings straight away.

## Run (development)
```
npm install
npm run dev
```
- Gallery: http://localhost:5173/
- Admin:   http://localhost:5173/admin/
- Login (development default): username `admin`, password `admin123`

`npm run dev` starts the Node server (port 4000) and Vite (port 5173) together. Vite forwards `/api` and `/uploads` to the server.

## Run (production)
```
cp .env.example .env        # then edit .env: set ADMIN_PASSWORD and JWT_SECRET
npm install
npm run build
npm start
```
Open http://localhost:4000/ (gallery) and http://localhost:4000/admin/. In production mode the server refuses to start unless `ADMIN_USERNAME`, `ADMIN_PASSWORD` and `JWT_SECRET` are set.

If you run production mode over plain `http` (no HTTPS), add `COOKIE_SECURE=false` to `.env`, otherwise the browser will not keep the login cookie.

## API
| Method | Path                 | Login? | What it does                                                 |
|--------|----------------------|--------|--------------------------------------------------------------|
| GET    | `/api/artworks`      | no     | List all drawings, newest first                              |
| POST   | `/api/artworks`      | yes    | Add a drawing (multipart: `title`, `description`, `price`, `image`) |
| PATCH  | `/api/artworks/:id`  | yes    | Edit fields, replace the image, or set `status` (`available`/`sold`) |
| DELETE | `/api/artworks/:id`  | yes    | Delete a drawing and its image file                          |
| POST   | `/api/auth/login`    | no     | `{ username, password }` → sets an httpOnly cookie           |
| POST   | `/api/auth/logout`   | no     | Clears the cookie                                            |
| GET    | `/api/auth/me`       | yes    | Who is logged in                                             |

## Where the data lives
`server/storage/db.json` (the drawings) and `server/storage/uploads/` (the images). Both are created on the first run, with six sample watercolors. Back up this folder, or point `STORAGE_DIR` somewhere permanent when you deploy. Delete the folder to reset to the samples.

## Structure
```
index.html, admin/index.html   the two pages
src/site/                      gallery (React)
src/admin/                     admin panel (React)
src/shared/api.js              API client used by both
server/                        Node.js backend
  index.js                     app setup, static files, error handling
  config.js                    environment settings
  auth.js, routes/auth.js      login (cookie + JWT), rate limit
  routes/artworks.js           drawings API and validation
  store.js                     JSON-file database
  upload.js                    image upload checks (type, size, file signature)
  seed/                        sample image
```

## Security notes
- Passwords are compared in constant time; login is limited to 10 attempts per 15 minutes per IP.
- The login cookie is `httpOnly` and `SameSite=Lax`; it is `Secure` in production.
- Uploads must be JPG, PNG or WebP, up to 8 MB, and the file's first bytes are checked too. Files are saved under random names.
- Behind a reverse proxy (nginx, Render, Railway…), set `TRUST_PROXY=1` so the rate limit sees real visitor IPs.
- The JSON file store suits one artist's gallery. If it grows a lot, or you run several server copies, move to a real database.
